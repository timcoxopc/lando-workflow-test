<?php

namespace Fixtures\Prophecy;

interface EmptyInterface
{
}
